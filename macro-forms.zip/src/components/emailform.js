import React from "react"
import { Form, Button } from 'react-bootstrap';

function EmailForm() {
  return (
    <Form>
      <Form.Group controlId="formBasicName">
        <Form.Control type="text" placeholder="Full Name" />
      </Form.Group>
      <Form.Group controlId="formBasicEmail">
        <Form.Control type="email" placeholder="Email Address" />
        <Form.Text className="text-muted">
        </Form.Text>
      </Form.Group>

      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
  )
}

export default EmailForm
